# israblog_backup
סקריפט גיבוי לישראבלוג

# description
Since Israblog is about to be closed I figured it'd be a good time to backup my mom's blog..  
This script should backup any blog on israblog to your computer in it's original format.  

# instructions  

There are two options to run the script:  
A. download "israblog_backup.py", "functions.js" and "include.js" files and run the python script.  
B. download "israblog_backup.zip" file, extract the content and run "israblog_backup.exe".  
  
After you ran it, it will ask you for your userID, which can be found here:  
<img src="https://i.imgur.com/SFo8axq.png">  

Insert the userID and after a few minutes (the exact time depends on how big is your blog) you should see a directory named "blog" with your blog in it, arranged by date. 

# What will work inside the blog
- next and previous month links
- page number links
- archive links on the side  
- show comments here and popup links  
- now saving pictures too  
- other things will probably not work, but you are welcome to try :P (I just worked on the essentials)  

# donations  
You are most welcome to use this for free but any donations will be appriciated ;)  
  
<a href="https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=8MRX7XCE66VGJ" rel="nofollow"><img src="https://camo.githubusercontent.com/f896f7d176663a1559376bb56aac4bdbbbe85ed1/68747470733a2f2f7777772e70617970616c6f626a656374732e636f6d2f656e5f55532f692f62746e2f62746e5f646f6e61746543435f4c472e676966" alt="paypal" data-canonical-src="https://www.paypalobjects.com/en_US/i/btn/btn_donateCC_LG.gif" style="max-width:100%;"></a>


